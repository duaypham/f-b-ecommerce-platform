<?php
require_once 'db.php';

$input = getJsonInput();
$action = $_GET['action'] ?? ($input['action'] ?? '');

if ($action === 'login') {
    $username = trim($input['username'] ?? '');
    $password = trim($input['password'] ?? '');

    $stmt = $pdo->prepare("SELECT id, username, fullName, phone, address, role FROM users WHERE username = ? AND password = ?");
    $stmt->execute([$username, $password]);
    $user = $stmt->fetch();

    if ($user) {
        if ($user['role'] === 'vendor') {
            $stStore = $pdo->prepare("SELECT * FROM stores WHERE vendor_username = ?");
            $stStore->execute([$user['username']]);
            $user['store'] = $stStore->fetch() ?: null;
        }
        echo json_encode(["success" => true, "user" => $user]);
    } else {
        echo json_encode(["success" => false, "message" => "Sai tên đăng nhập hoặc mật khẩu!"]);
    }
    exit();
}

if ($action === 'register') {
    $username = trim($input['username'] ?? '');
    $password = trim($input['password'] ?? '');
    $fullName = trim($input['fullName'] ?? '');
    $phone = trim($input['phone'] ?? '');
    $address = trim($input['address'] ?? '');
    $role = $input['role'] ?? 'customer';
    $storeName = trim($input['storeName'] ?? ($fullName . ' Store'));

    if (!$username || !$password || !$fullName) {
        echo json_encode(["success" => false, "message" => "Vui lòng điền đầy đủ thông tin bắt buộc!"]);
        exit();
    }

    $check = $pdo->prepare("SELECT id FROM users WHERE username = ?");
    $check->execute([$username]);
    if ($check->fetch()) {
        echo json_encode(["success" => false, "message" => "Tên đăng nhập đã tồn tại!"]);
        exit();
    }

    $stmt = $pdo->prepare("INSERT INTO users (username, password, fullName, phone, address, role) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([$username, $password, $fullName, $phone, $address, $role]);

    $storeData = null;
    if ($role === 'vendor') {
        $stStore = $pdo->prepare("INSERT INTO stores (vendor_username, storeName, phone, address) VALUES (?, ?, ?, ?)");
        $stStore->execute([$username, $storeName, $phone, $address]);
        $storeId = $pdo->lastInsertId();
        $storeData = ["id" => (int)$storeId, "vendor_username" => $username, "storeName" => $storeName, "commissionRate" => 10];
    }

    echo json_encode([
        "success" => true,
        "message" => "Đăng ký thành công!",
        "user" => [
            "username" => $username,
            "fullName" => $fullName,
            "phone" => $phone,
            "address" => $address,
            "role" => $role,
            "store" => $storeData
        ]
    ]);
    exit();
}

if ($action === 'update_profile') {
    $username = trim($input['username'] ?? '');
    $fullName = trim($input['fullName'] ?? '');
    $phone = trim($input['phone'] ?? '');
    $address = trim($input['address'] ?? '');
    $newPassword = trim($input['newPassword'] ?? '');

    if ($newPassword !== '') {
        $stmt = $pdo->prepare("UPDATE users SET fullName = ?, phone = ?, address = ?, password = ? WHERE username = ?");
        $stmt->execute([$fullName, $phone, $address, $newPassword, $username]);
    } else {
        $stmt = $pdo->prepare("UPDATE users SET fullName = ?, phone = ?, address = ? WHERE username = ?");
        $stmt->execute([$fullName, $phone, $address, $username]);
    }

    $stmtUser = $pdo->prepare("SELECT id, username, fullName, phone, address, role FROM users WHERE username = ?");
    $stmtUser->execute([$username]);
    $user = $stmtUser->fetch();

    if ($user && $user['role'] === 'vendor') {
        $stStore = $pdo->prepare("SELECT * FROM stores WHERE vendor_username = ?");
        $stStore->execute([$username]);
        $user['store'] = $stStore->fetch() ?: null;
    }

    echo json_encode(["success" => true, "message" => "Cập nhật hồ sơ thành công!", "user" => $user]);
    exit();
}

echo json_encode(["success" => false, "message" => "Action không hợp lệ"]);
?>