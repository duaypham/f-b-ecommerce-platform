<?php
require_once 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $sql = "SELECT v.*, s.storeName 
            FROM vouchers v 
            LEFT JOIN stores s ON v.store_id = s.id 
            ORDER BY v.id DESC";
    $stmt = $pdo->query($sql);
    $vouchers = $stmt->fetchAll();
    foreach ($vouchers as &$v) {
        $v['id'] = (int)$v['id'];
        $v['store_id'] = $v['store_id'] !== null ? (int)$v['store_id'] : null;
        $v['value'] = (int)$v['value'];
        $v['minOrder'] = (int)$v['minOrder'];
        $v['maxDiscount'] = (int)$v['maxDiscount'];
        $v['isActive'] = (int)$v['isActive'] === 1;
    }
    echo json_encode(["success" => true, "vouchers" => $vouchers]);
    exit();
}

$input = getJsonInput();
$action = $input['action'] ?? '';

if ($action === 'save') {
    $id = isset($input['id']) ? (int)$input['id'] : 0;
    $store_id = !empty($input['store_id']) ? (int)$input['store_id'] : null;
    $code = strtoupper(trim($input['code'] ?? ''));
    $title = trim($input['title'] ?? '');
    $type = $input['type'] ?? 'fixed';
    $value = (int)($input['value'] ?? 0);
    $minOrder = (int)($input['minOrder'] ?? 0);
    $maxDiscount = (int)($input['maxDiscount'] ?? $value);
    $isActive = isset($input['isActive']) ? ($input['isActive'] ? 1 : 0) : 1;

    // Kiểm tra trùng mã code trước khi thêm/cập nhật
    $stCheck = $pdo->prepare("SELECT id FROM vouchers WHERE code = ? AND id != ?");
    $stCheck->execute([$code, $id]);
    if ($stCheck->fetch()) {
        echo json_encode([
            "success" => false,
            "message" => "Mã giảm giá '$code' đã tồn tại trên hệ thống! Vui lòng đặt mã khác."
        ]);
        exit();
    }

    if ($id > 0) {
        $stmt = $pdo->prepare("UPDATE vouchers SET code=?, title=?, type=?, value=?, minOrder=?, maxDiscount=?, isActive=? WHERE id=?");
        $stmt->execute([$code, $title, $type, $value, $minOrder, $maxDiscount, $isActive, $id]);
        echo json_encode(["success" => true, "message" => "Cập nhật mã giảm giá thành công!"]);
    } else {
        $stmt = $pdo->prepare("INSERT INTO vouchers (store_id, code, title, type, value, minOrder, maxDiscount, isActive) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$store_id, $code, $title, $type, $value, $minOrder, $maxDiscount, $isActive]);
        echo json_encode(["success" => true, "message" => "Đã phát hành mã giảm giá mới!"]);
    }
    exit();
}

if ($action === 'delete') {
    $id = (int)($input['id'] ?? 0);
    $stmt = $pdo->prepare("DELETE FROM vouchers WHERE id = ?");
    $stmt->execute([$id]);
    echo json_encode(["success" => true, "message" => "Đã xóa mã giảm giá!"]);
    exit();
}

echo json_encode(["success" => false, "message" => "Action không hợp lệ"]);
?>