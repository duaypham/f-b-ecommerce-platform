<?php
require_once 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $stmt = $pdo->query("SELECT o.*, s.storeName, s.address AS storeAddress, s.phone AS storePhone 
                         FROM orders o 
                         LEFT JOIN stores s ON o.store_id = s.id 
                         ORDER BY o.id DESC");
    $orders = $stmt->fetchAll();

    foreach ($orders as &$o) {
        $o['id'] = (int)$o['id'];
        $o['store_id'] = (int)$o['store_id'];
        $o['subTotal'] = (int)$o['subTotal'];
        $o['discountAmount'] = (int)$o['discountAmount'];
        $o['platformFee'] = (int)$o['platformFee'];
        $o['totalAmount'] = (int)$o['totalAmount'];
        $o['items'] = json_decode($o['itemsJson'], true) ?? [];
    }

    echo json_encode(["success" => true, "orders" => $orders]);
    exit();
}

$input = getJsonInput();
$action = $input['action'] ?? '';

if ($action === 'create') {
    $orderCode = $input['orderCode'] ?? ('ORD' . rand(100000, 999999));
    $store_id = (int)($input['store_id'] ?? 1);
    $username = $input['username'] ?? '';
    $customerName = $input['customerName'] ?? '';
    $phone = $input['phone'] ?? '';
    $address = $input['address'] ?? '';
    $note = $input['note'] ?? '';
    $paymentMethod = $input['paymentMethod'] ?? 'COD';
    $paymentStatus = $input['paymentStatus'] ?? ($paymentMethod === 'COD' ? 'Thanh toán khi nhận hàng' : 'Đã thanh toán QR');
    $voucherCode = $input['voucherCode'] ?? null;
    // Kiểm tra mỗi tài khoản chỉ được sử dụng mỗi mã Voucher 1 lần duy nhất
    if (!empty($voucherCode)) {
        $stmtCheckVoucher = $pdo->prepare("SELECT COUNT(*) FROM orders WHERE username = ? AND UPPER(voucherCode) = UPPER(?) AND status != 'Đã hủy'");
        $stmtCheckVoucher->execute([$username, $voucherCode]);
        if ((int)$stmtCheckVoucher->fetchColumn() > 0) {
            echo json_encode([
                "success" => false,
                "message" => "Tài khoản của bạn đã sử dụng mã $voucherCode trước đó rồi!"
            ]);
            exit();
        }
    }
    $subTotal = (int)($input['subTotal'] ?? 0);
    $discountAmount = (int)($input['discountAmount'] ?? 0);
    $totalAmount = (int)($input['totalAmount'] ?? 0);
    $items = $input['items'] ?? [];

    $platformFee = (int)round($subTotal * 0.10);
    $itemsJson = json_encode($items, JSON_UNESCAPED_UNICODE);

    $stmt = $pdo->prepare("INSERT INTO orders (orderCode, store_id, username, customerName, phone, address, note, paymentMethod, paymentStatus, voucherCode, subTotal, discountAmount, platformFee, totalAmount, itemsJson, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Đang chuẩn bị')");
    $stmt->execute([$orderCode, $store_id, $username, $customerName, $phone, $address, $note, $paymentMethod, $paymentStatus, $voucherCode, $subTotal, $discountAmount, $platformFee, $totalAmount, $itemsJson]);

    $stUpdateSold = $pdo->prepare("UPDATE products SET soldCount = soldCount + ? WHERE id = ?");
    foreach ($items as $item) {
        $qty = (int)($item['quantity'] ?? 1);
        $pId = (int)($item['productId'] ?? 0);
        if ($pId > 0) {
            $stUpdateSold->execute([$qty, $pId]);
        }
    }

    echo json_encode(["success" => true, "message" => "Đặt hàng thành công!", "orderCode" => $orderCode]);
    exit();
}

if ($action === 'update_status') {
    $orderCode = $input['orderCode'] ?? '';
    $status = $input['status'] ?? '';
    $shipper_username = $input['shipper_username'] ?? null;
    $shipperName = $input['shipperName'] ?? null;

    if ($shipper_username) {
        $stmt = $pdo->prepare("UPDATE orders SET status = ?, shipper_username = ?, shipperName = ? WHERE orderCode = ? AND status = 'Chờ tài xế nhận'");
        $stmt->execute([$status, $shipper_username, $shipperName, $orderCode]);

        if ($stmt->rowCount() === 0) {
            echo json_encode([
                "success" => false,
                "message" => "Chậm tay mất rồi! Đơn hàng này vừa được tài xế khác nhận giao."
            ]);
            exit();
        }
    } else {
        // Nếu đơn hoàn tất bằng COD, cập nhật luôn trạng thái đã thu tiền
        if ($status === 'Hoàn tất') {
            $stmt = $pdo->prepare("UPDATE orders SET status = ?, paymentStatus = CASE WHEN paymentMethod = 'COD' THEN 'Đã thu tiền mặt' ELSE paymentStatus END WHERE orderCode = ?");
            $stmt->execute([$status, $orderCode]);
        } else {
            $stmt = $pdo->prepare("UPDATE orders SET status = ? WHERE orderCode = ?");
            $stmt->execute([$status, $orderCode]);
        }
    }

    echo json_encode(["success" => true, "message" => "Đã cập nhật trạng thái đơn hàng thành: $status"]);
    exit();
}

echo json_encode(["success" => false, "message" => "Action không hợp lệ"]);
?>