<?php
require_once 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $product_id = isset($_GET['product_id']) ? (int)$_GET['product_id'] : 0;
    if ($product_id > 0) {
        $stmt = $pdo->prepare("SELECT * FROM reviews WHERE product_id = ? ORDER BY id DESC");
        $stmt->execute([$product_id]);
    } else {
        $stmt = $pdo->query("SELECT * FROM reviews ORDER BY id DESC");
    }
    echo json_encode(["success" => true, "reviews" => $stmt->fetchAll()]);
    exit();
}

$input = getJsonInput();
$action = $input['action'] ?? '';

if ($action === 'add') {
    $orderCode = $input['orderCode'] ?? '';
    $product_id = (int)($input['product_id'] ?? 0);
    $username = $input['username'] ?? '';
    $fullName = $input['fullName'] ?? $username;
    $rating = (int)($input['rating'] ?? 5);
    $comment = trim($input['comment'] ?? '');

    // Kiểm tra xem người dùng đã đánh giá món này trong đơn hàng này chưa
    $check = $pdo->prepare("SELECT id FROM reviews WHERE orderCode = ? AND product_id = ? AND username = ?");
    $check->execute([$orderCode, $product_id, $username]);
    if ($check->fetch()) {
        echo json_encode(["success" => false, "message" => "Bạn đã đánh giá món này trong đơn hàng này rồi!"]);
        exit();
    }

    $stmt = $pdo->prepare("INSERT INTO reviews (orderCode, product_id, username, fullName, rating, comment) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([$orderCode, $product_id, $username, $fullName, $rating, $comment]);

    echo json_encode(["success" => true, "message" => "Cảm ơn bạn đã gửi đánh giá!"]);
    exit();
}

echo json_encode(["success" => false, "message" => "Action không hợp lệ"]);
?>