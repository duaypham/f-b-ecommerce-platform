<?php
require_once 'db.php';

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $sql = "SELECT p.*, s.storeName, s.vendor_username,
            COALESCE(ROUND(AVG(r.rating), 1), 0) AS avgRating,
            COUNT(r.id) AS reviewCount
            FROM products p
            JOIN stores s ON p.store_id = s.id
            LEFT JOIN reviews r ON p.id = r.product_id
            GROUP BY p.id
            ORDER BY p.soldCount DESC, p.isBestSeller DESC, p.id DESC";
    $stmt = $pdo->query($sql);
    $products = $stmt->fetchAll();

    foreach ($products as &$p) {
        $p['id'] = (int)$p['id'];
        $p['store_id'] = (int)$p['store_id'];
        $p['basePrice'] = (int)$p['basePrice'];
        $p['discountPrice'] = (int)$p['discountPrice'];
        $p['isBestSeller'] = (int)$p['isBestSeller'] === 1;
        $p['isAvailable'] = (int)$p['isAvailable'] === 1;
        $p['soldCount'] = (int)$p['soldCount'];
        $p['avgRating'] = (float)$p['avgRating'];
        $p['reviewCount'] = (int)$p['reviewCount'];
    }

    $stStores = $pdo->query("SELECT * FROM stores ORDER BY id ASC");
    $stores = $stStores->fetchAll();

    $stWarnings = $pdo->query("SELECT w.*, s.storeName FROM warnings w JOIN stores s ON w.store_id = s.id ORDER BY w.id DESC");
    $warnings = $stWarnings->fetchAll();
    foreach ($warnings as &$w) {
        $w['id'] = (int)$w['id'];
        $w['store_id'] = (int)$w['store_id'];
        $w['isResolved'] = (int)$w['isResolved'] === 1;
    }

    echo json_encode([
        "success" => true,
        "products" => $products,
        "stores" => $stores,
        "warnings" => $warnings
    ]);
    exit();
}

$input = getJsonInput();
$action = $input['action'] ?? '';
$role = $input['role'] ?? 'vendor';

// CHỈ CHỦ CỬA HÀNG (VENDOR) MỚI ĐƯỢC THÊM / SỬA THỰC ĐƠN CỦA QUÁN MÌNH
if ($action === 'save') {
    if ($role === 'admin') {
        echo json_encode([
            "success" => false,
            "message" => "Quản trị viên sàn không được phép chỉnh sửa trực tiếp thực đơn của cửa hàng!"
        ]);
        exit();
    }

    $id = isset($input['id']) ? (int)$input['id'] : 0;
    $store_id = (int)($input['store_id'] ?? 1);
    $name = trim($input['name'] ?? '');
    $category = trim($input['category'] ?? 'Trà sữa');
    $basePrice = (int)($input['basePrice'] ?? 0);
    $discountPrice = (int)($input['discountPrice'] ?? 0);
    $image = trim($input['image'] ?? 'https://images.unsplash.com/photo-1558857563-b371033873b8?w=600');
    $description = trim($input['description'] ?? '');
    $isBestSeller = !empty($input['isBestSeller']) ? 1 : 0;
    $isAvailable = isset($input['isAvailable']) ? ($input['isAvailable'] ? 1 : 0) : 1;

    if ($id > 0) {
        $stmt = $pdo->prepare("UPDATE products SET name=?, category=?, basePrice=?, discountPrice=?, image=?, description=?, isBestSeller=?, isAvailable=? WHERE id=? AND store_id=?");
        $stmt->execute([$name, $category, $basePrice, $discountPrice, $image, $description, $isBestSeller, $isAvailable, $id, $store_id]);
        echo json_encode(["success" => true, "message" => "Đã cập nhật món ăn thành công!"]);
    } else {
        $stmt = $pdo->prepare("INSERT INTO products (store_id, name, category, basePrice, discountPrice, image, description, isBestSeller, isAvailable) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$store_id, $name, $category, $basePrice, $discountPrice, $image, $description, $isBestSeller, $isAvailable]);
        echo json_encode(["success" => true, "message" => "Đã thêm món mới lên thực đơn quán!"]);
    }
    exit();
}

if ($action === 'toggle_availability') {
    if ($role === 'admin') {
        echo json_encode(["success" => false, "message" => "Chỉ cửa hàng mới được bật/tắt trạng thái món!"]);
        exit();
    }
    $id = (int)($input['id'] ?? 0);
    $isAvailable = !empty($input['isAvailable']) ? 1 : 0;
    $stmt = $pdo->prepare("UPDATE products SET isAvailable = ? WHERE id = ?");
    $stmt->execute([$isAvailable, $id]);
    echo json_encode(["success" => true, "message" => "Đã cập nhật trạng thái phục vụ!"]);
    exit();
}

// XÓA MÓN (VENDOR TỰ XÓA HOẶC ADMIN GỠ MÓN VI PHẠM KÈM CẢNH CÁO)
if ($action === 'delete') {
    $id = (int)($input['id'] ?? 0);
    $reason = trim($input['reason'] ?? '');

    if ($role === 'admin' && $reason !== '') {
        $stProd = $pdo->prepare("SELECT store_id, name FROM products WHERE id = ?");
        $stProd->execute([$id]);
        $prod = $stProd->fetch();
        if ($prod) {
            $stWarn = $pdo->prepare("INSERT INTO warnings (store_id, product_name, message) VALUES (?, ?, ?)");
            $stWarn->execute([$prod['store_id'], $prod['name'], "[ĐÃ GỠ SẢN PHẨM VI PHẠM] Lý do: " . $reason]);
        }
    }

    $stmt = $pdo->prepare("DELETE FROM products WHERE id = ?");
    $stmt->execute([$id]);
    echo json_encode(["success" => true, "message" => "Đã xóa sản phẩm khỏi hệ thống!"]);
    exit();
}

// ADMIN GỬI LỜI CẢNH CÁO VI PHẠM ĐẾN CỬA HÀNG
if ($action === 'send_warning') {
    $store_id = (int)($input['store_id'] ?? 0);
    $product_name = trim($input['product_name'] ?? 'Sản phẩm cửa hàng');
    $message = trim($input['message'] ?? '');

    if ($store_id <= 0 || !$message) {
        echo json_encode(["success" => false, "message" => "Vui lòng nhập nội dung cảnh cáo!"]);
        exit();
    }

    $stmt = $pdo->prepare("INSERT INTO warnings (store_id, product_name, message) VALUES (?, ?, ?)");
    $stmt->execute([$store_id, $product_name, $message]);
    echo json_encode(["success" => true, "message" => "Đã gửi cảnh cáo vi phạm đến cửa hàng!"]);
    exit();
}

// CỬA HÀNG XÁC NHẬN ĐÃ ĐỌC & KHẮC PHỤC CẢNH CÁO
if ($action === 'resolve_warning') {
    $id = (int)($input['id'] ?? 0);
    $stmt = $pdo->prepare("UPDATE warnings SET isResolved = 1 WHERE id = ?");
    $stmt->execute([$id]);
    echo json_encode(["success" => true, "message" => "Đã xác nhận khắc phục cảnh cáo!"]);
    exit();
}

echo json_encode(["success" => false, "message" => "Yêu cầu không hợp lệ"]);
?>